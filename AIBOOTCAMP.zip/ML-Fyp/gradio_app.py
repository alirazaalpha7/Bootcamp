import gradio as gr
import pandas as pd
from model import recommend_songs  # Assuming you have this function in your model file

# Load your Spotify data (use the correct file name 'data.csv')
spotify_data = pd.read_csv(r'C:\\Users\\alira\\OneDrive\\Desktop\\ML-Fyp\\data.csv')


# Gradio UI function
def recommend_songs_ui(song_input):
    songs = song_input.split(",")  # Assuming input is comma-separated
    recommendations = recommend_songs(songs, spotify_data, n_songs=5)
    return recommendations

# Create the Gradio interface
iface = gr.Interface(
    fn=recommend_songs_ui,
    inputs=gr.Textbox(label="Enter songs (comma-separated)"),
    outputs=gr.Dataframe(label="Recommendations"),
    title="Song Recommendation System",
    description="Enter your favorite songs to get recommendations."
)

# Launch the Gradio interface
iface.launch(share=True)

