from flask import Flask, request, jsonify, render_template
import pandas as pd
from model import recommend_songs  # Import your recommendation function

app = Flask(__name__)

# Load your Spotify data (using a relative path for deployment)
# Make sure 'data.csv' is in the same directory as this script or in a subdirectory.
spotify_data = pd.read_csv('data.csv')  # Adjust this based on your file structure

@app.route('/')
def home():
    return render_template('index.html')  # Render the HTML page

@app.route('/recommend', methods=['POST'])
def recommend():
    data = request.get_json()
    song_list = data['songs']
    recommendations = recommend_songs(song_list, spotify_data, n_songs=5)  # Adjust n_songs as needed
    return jsonify(recommendations)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=7860)  # Use 7860 for Hugging Face Spaces
